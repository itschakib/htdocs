package t1p4e1;

import java.util.Scanner;

public class T1P4E1 {

    public static void main(String[] args) {
        Scanner consola = new Scanner(System.in);
        System.out.println("Array de valores creado");

        //creamos un array entre 50 y 5
        int[] array = new int[10];
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) (Math.random() * (50 - 5 + 1) + 5);
        }
        //Pedir al usuario un numero válido entre 5 y 50
        int num;
        do {
            System.out.print("Introduce un tamano entre 5 y 50:");
            num = consola.nextInt();
            if (num < 5 || num > 50) {
                System.out.println("ERROR. El numero introducido no esta en el rango indicado");
            }
        } while (num < 5 || num > 50);
        //compramos si el numero esta en el array
        boolean encontrado = false;
        int posicion = -1;
        for (int i = 0; i < array.length; i++) {
            if (array[i] == num) {
                encontrado = true;
                posicion = i;
            }
        }
        //resultado
        if (encontrado) {
            System.out.println("El numero " + num + " ESTA EN EL ARRAY y su primer posicion es la " + (posicion+1));
        } else {
            System.out.println("EL numero " + num + " NO ESTA EN EL ARRAY");
        }
        //monstramos el array 
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }
}

































        