package t1p4e2;

import java.util.Scanner;

public class T1P4E2 {

    public static void main(String[] args) {
        Scanner consola = new Scanner(System.in);
        int x = 0;
        do {
            System.out.println("Introduzca un tamano entre -3 y 10 :");
            x = consola.nextInt();
            if (x <= -3 || x >= 10) {
                System.out.println("Error. el tamano introducido no esta en el rango indicado.");
            }
        } while (x <= -3 || x >= 10);
        double[] array = new double[x];
        System.out.println("Solicitando notas:");
        for (int i = 0; i < array.length; i++) {
            do{
            System.out.print("\nIntroduce nota " + (i+1) + " : ");
            array[i] = consola.nextDouble();
          if(array[i]<0||array[i]>10){
              System.out.println("ERROR. Nota incorrecta!!");
          }
         }while(array[i]<0||array[i]>10);
        }

        double suma = 0;
        for (int i = 0; i < array.length; i++) {
            suma += array[i];
        }
        double media = suma / array.length;

        double mayor = array[0];
        double menor = array[0];
        for (int i = 0; i < array.length; i++) {
            if (array[i] > mayor) {
                mayor = array[i];
            }
            if (array[i] < menor) {
                menor = array[i];
            }
        }
        System.out.print("Notas:");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + ", ");
        }
        
        
        System.out.println();
        System.out.println("Media :" + media);
        System.out.println("Mayor nota :" + mayor);
        System.out.println("Menor nota :" + menor);
    }

}