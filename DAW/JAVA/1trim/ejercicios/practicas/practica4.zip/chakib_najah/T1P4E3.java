package t1p4e3;

import java.util.Scanner;

public class T1P4E3 {

    public static void main(String[] args) {
        Scanner consola = new Scanner(System.in);

        //A)
        System.out.println("APARTADO A");
        int N = 0;
        do {
            System.out.print("Introduce un valor mayor a 1 ");
            N = consola.nextInt();
            if (N <= 1) {
                System.out.println("Error!! El numero debe ser mayor a 1");
            }
        } while (N <= 1);

        //B)
        System.out.println("APARTADO B");
        int[][]matriz=new int[N][N];

        for(int i=0; i<matriz.length; i++) {
            for(int k=0; k<matriz[i].length; k++) {
                matriz[i][k]=(int)(Math.random()*(20-2+1)+2);
            }
        }

        //C)
        System.out.println("APARTADO C");

        for(int i= 0; i<matriz.length;i++) {
            for(int j= 0; j<matriz[i].length;j++) {
                if (matriz[i][j]<10) {
                    System.out.print("0"+matriz[i][j]+ " "); 
                }else{
                    System.out.print(matriz[i][j]+" ");
                }
            }
            System.out.println();
        }
        //D)
        System.out.println("APARTADO D");
        int[][]copia=new int[N][N];
        for(int i=0; i<matriz.length;i++) {
            for (int j=0; j<matriz[i].length;j++) {
                if(matriz[i][j]>10) {
                    copia[i][j]=9;
                } else {
                    copia[i][j]=matriz[i][j];
                }
            }
        }
        //E)
        for(int i=0;i<copia.length;i++) {
            for (int j=0; j<copia[i].length;j++) {
                if(copia[i][j]<10) {
                    System.out.print("0"+copia[i][j] +" ");
                } else {
                    System.out.print(copia[i][j]+" ");
                }
            }
            System.out.println();
        }
        long resultado = 1;

        for(int i=0;i<N;i++) {
            resultado*=matriz[i][i];
        }
        System.out.println("APARTADO E");
        System.out.println("La multiplicacion de ambas diagonales principales es : " + resultado);

        //F)
        System.out.println("APARTADO F");
        int num=0;
        do{
            System.out.print("Dime que fila debo intercambiar 1 y " + N);
            num=consola.nextInt();
            if (num<1||num>N) {
                System.out.println("Error!! El numero debe estar entre 1 y " + N);
            }
        } while(num<1||num>N);
        num--;

        //cambiar filas
        for (int j=0;j<N;j++) {
            int filatemporal=matriz[num][j];
            matriz[num][j]=copia[num][j];
            copia[num][j]=filatemporal;
        }

        // Mostrar las dos matarices
        System.out.println("MATRIZ");
        for(int i=0;i<N;i++) {
            for(int j=0;j<N;j++) {
                if(matriz[i][j]<10) {
                    System.out.print("0"+matriz[i][j]+" ");
                }else{
                    System.out.print(matriz[i][j]+" ");
                }
            }
            System.out.println();
        }

        System.out.println("COPIA");
        for(int i=0;i<N;i++) {
            for(int j=0;j<N;j++) {
                if (copia[i][j] < 10) {
                    System.out.print("0"+copia[i][j]+" ");
                } else {
                    System.out.print(copia[i][j]+" ");
                }
            }
            System.out.println();
        }

    }

}
